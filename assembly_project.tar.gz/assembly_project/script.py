#!/usr/bin/env python
#  scrity.py
#  
#  

#import os
import subprocess
#from mutator import mutate, sample_positions, display_snp_distr 
#import argparse
#import arg_lists


		


def main(args):
    
    
    #seq_gen_args = arg_lists.seq_gen_args
    #arg_lists.art_illumina_args_something_specific1
    
    
    command = ['./Seq-Gen/source/run_seq_gen.sh']
    #command.extend(seq_gen_args)
    
    
    #--run the seq-gen program which will output the resulting fasta
    #  file in the "sample data" directory in the art illumina directory
    subprocess.Popen(command, stdout=subprocess.PIPE).communicate()[0]
      
    
    command = ['./art_illumina/sample_data/run_art_illumina.sh']
    #command.extend(art_illumina_args)
    
    #--run the art illumina program with the sample data generated
    #  from seq-gen
    subprocess.Popen(command, stdout=subprocess.PIPE).communicate()[0]
    
    
    print("===end===")
    return 0
    
    

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
