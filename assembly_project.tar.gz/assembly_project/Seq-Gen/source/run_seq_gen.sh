#!/bin/bash
#illumina test examples

#NOTE: this was important
cd $(dirname $0)


#model=$1
#seq_len=$2


model="-m HKY"
length="-l 50"
seed="-z 3"

# NOTE: has it's own trees folder
tree="trees/example.tree"



./seq-gen $model $seq_len $seed -of $tree > /home/scores-man/Coursework/CS980/assembly_project/art_illumina/sample_data/seq_gen_fasta.fna


