#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  Tim Ward
#  arg_lists.py
#
#  Alliviate the exhaustive command line args with specified
#  argument lists
#  


seq_gen_args = {

	# This arg is necessary
	'-m HKY', # which model
	
	#--Enter args here--------------------------------------------
	#'-l 100', # sequence length
	#'-z 1', # seed value
	#-------------------------------------------------------------
	
	# last arg is tree file (has no flag)
	# if unspecified, will expect stdin 
	'./trees/example.tree'
	
	# NOTE: dummy paramaters caused warnings (no surprise...)
	#'./trees/heterogeneity.tree'
	
	
}


# (basic) parameters from the art test script
art_illumina_args_something_specific1 = {
	
	'-l 35', # TODO (figure out this parameter)
	'-f 10', # TODO (figure out this parameter)
	'-sam', # TODO (figure out this parameter)
	'-k 0' # TODO (figure out this parameter)

}


# (basic) parameters from the art test script
art_illumina_args_something_specific2 = {
	
	'-l 50', # TODO (figure out this parameter)
	'-f 10', # TODO (figure out this parameter)
	#'-sam', # TODO (figure out this parameter)
	'-k 5' # TODO (figure out this parameter)

}


