"""
This very basic mutator takes a file containing a single, complete, ground truth genome (see example test_01) and a
parameter k which is the number of mutations you want to apply to it. Then it creates a new sequence with exactly k
mutations.
Example command line: python basic_mutator.py test_01.fna 1 ALISON
"""



import random
import heapq
import copy
import os

		


mutation_model = {
'A':'TCG',
'T':'CGA',
'C':'GAT',
'G':'ATC'
}



def sample_positions(sequence, k, seed):
    random.seed(seed)
    last_position = len(sequence) - 1
    k_random_positions = random.sample(range(last_position), k)
    return k_random_positions



def mutate(sequence, k_random_positions):
	print("MUTATING SEQUENCE: " + str(k_random_positions))
	new_sequence = list(sequence)
	for position in k_random_positions:
		orig_nucleotide = sequence[position]
		try:
			new_nuc = random.choice(mutation_model[orig_nucleotide])
		except:
			new_nuc = orig_nucleotide
		new_sequence[position] = new_nuc
	return ''.join(new_sequence)
		
		


def snp_density_distribution(sequence, snp_positions, interval):
    min_heap = copy.copy(snp_positions)
    heapq.heapify(min_heap)
    end_position = interval - 1
    count = 0
    distribution = {}
    while end_position < len(sequence) + interval:
        if len(min_heap) > 0 and min_heap[0] <= end_position:
            heapq.heappop(min_heap)
            count += 1
        else:
            end_position += interval
            distribution[count] = distribution.get(count, 0) + 1
            count = 0
    return distribution
    
    
def display_snp_distr(header, sequence, random_positions, interval=100):
    snp_distribution = snp_density_distribution(sequence, random_positions, interval)
    print("{0} | snp density distribution: {1}".format(header, snp_distribution))
    print("{0}".format(sequence))


if __name__ == "__main__":
    pass

