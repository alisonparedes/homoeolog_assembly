#!/bin/bash
#illumina test examples

#NOTE: this was important
cd $(dirname $0)



art=../art_illumina
#art=../../bin/MacOS64/art_illumina
#art=../../bin/Linux64/art_illumina



#k_val=$1
#seed_val=$2

#-------------------
#echo $k_val
#echo $seed_val
#-------------------




# 1) simulation of single-end reads of 35bp with 10X using the built-in combined quality profile, and without Indels
$art -ss GA1 -i ./seq_gen_fasta.fna -o ./single_end_com -l 35 -f 10 -sam -k 0
#convert an aln file to a bed file
../aln2bed.pl single_end_com.bed single_end_com.aln

# 2) simulation of single-end reads of 50bp with 10X using the built-in seperated quality profiles for A, C, G, and T 
$art -ss MinS -i ./seq_gen_fasta.fna -o ./single_end_sep -l 50 -f 10 -sp -sam
#convert an aln file to a bed file
../aln2bed.pl single_end_sep.bed single_end_sep.aln



